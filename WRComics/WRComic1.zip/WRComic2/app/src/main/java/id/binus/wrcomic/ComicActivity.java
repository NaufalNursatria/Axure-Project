package id.binus.wrcomic;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;

public class ComicActivity extends AppCompatActivity {

    ImageView imageView;
    TextView tvTitle, tvAuthor, tvDesc;
    TextInputEditText etQty;
    Button btnOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comic);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        imageView = findViewById(R.id.iv_comic);
        tvTitle = findViewById(R.id.tv_comic_title);
        tvAuthor = findViewById(R.id.tv_comic_author);
        tvDesc = findViewById(R.id.tv_comic_desc);
        etQty = findViewById(R.id.et_qty);
        btnOrder = findViewById(R.id.btn_order);

        final Intent intent = getIntent();
        Glide.with(this).load(intent.getStringExtra("image")).into(imageView);
        tvTitle.setText(intent.getStringExtra("title"));
        tvAuthor.setText(intent.getStringExtra("author"));
        tvDesc.setText(intent.getStringExtra("desc"));

        btnOrder.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("DefaultLocale")
            @Override
            public void onClick(View v) {
                btnOrder.setBackgroundColor(getColor(R.color.purple_200));

                String input = etQty.getText().toString();

                if (input.isEmpty()) {
                    showDialog("Empty Input", "Input field cannot be empty");
                } else {
                    int qty = Integer.parseInt(etQty.getText().toString());

                    if (qty <= 0) {
                        btnOrder.setBackgroundColor(getColor(R.color.purple_500));
                        showDialog("Invalid Quantity", "Quantity must be greater than 0");
                    } else {
                        showDialog("Success", String.format("Added %d %s to Chart", qty, intent.getStringExtra("title")));
                        btnOrder.setBackgroundColor(getColor(R.color.purple_500));
                    }
                }
            }
        });
    }

    private void showDialog(String title, String message) {
        new MaterialAlertDialogBuilder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}