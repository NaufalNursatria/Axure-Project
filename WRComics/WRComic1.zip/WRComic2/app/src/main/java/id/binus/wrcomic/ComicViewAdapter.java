package id.binus.wrcomic;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

/**
 * Created by IsmailR on 10/06/21.
 */
public class ComicViewAdapter extends RecyclerView.Adapter<ComicViewAdapter.ViewHolder> {
    private final List<Comic> comicList;
    private final LayoutInflater mInflater;

    ComicViewAdapter(Context context, List<Comic> comicList) {
        this.mInflater = LayoutInflater.from(context);
        this.comicList = comicList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.comic_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final Comic comic = comicList.get(position);

        //implementasi glide
        //https://bumptech.github.io/glide/

        Glide.with(holder.itemView)
                .load(comic.getCover())
                .into(holder.imageView);
        holder.tvTitle.setText(comic.getTitle());
        holder.tvAuthor.setText(comic.getAuthor());
        holder.tvDesc.setText(comic.getDesc());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.itemView.getContext().startActivity(
                        new Intent(holder.itemView.getContext(),
                                ComicActivity.class)
                                .putExtra("image", comic.getCover())
                                .putExtra("title", comic.getTitle())
                                .putExtra("author", comic.getAuthor())
                                .putExtra("desc", comic.getDesc())
                );
            }
        });
    }

    @Override
    public int getItemCount() {
        return comicList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView tvTitle, tvAuthor, tvDesc;

        ViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.iv_comic);
            tvTitle = itemView.findViewById(R.id.tv_comic_title);
            tvAuthor = itemView.findViewById(R.id.tv_comic_author);
            tvDesc = itemView.findViewById(R.id.tv_comic_desc);
        }
    }
}
