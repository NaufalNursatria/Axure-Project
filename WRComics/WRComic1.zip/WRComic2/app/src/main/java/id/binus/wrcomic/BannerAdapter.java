package id.binus.wrcomic;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.smarteist.autoimageslider.SliderViewAdapter;

import java.util.List;

/**
 * Created by IsmailR on 10/06/21.
 */
public class BannerAdapter extends SliderViewAdapter<BannerAdapter.BannerViewHolder> {
    private final Context context;
    private final List<String> list;

    public BannerAdapter(Context context, List<String> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public BannerViewHolder onCreateViewHolder(ViewGroup parent) {
        @SuppressLint("InflateParams")
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.banner_item, null);
        return new BannerViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(BannerViewHolder viewHolder, final int position) {
        String sliderItem = list.get(position);
        Glide.with(viewHolder.itemView)
                .load(sliderItem)
                .fitCenter()
                .into(viewHolder.imageViewBackground);

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "This is item in position " + position, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getCount() {
        return list.size();
    }

    static class BannerViewHolder extends SliderViewAdapter.ViewHolder {
        View itemView;
        ImageView imageViewBackground;

        public BannerViewHolder(View itemView) {
            super(itemView);
            imageViewBackground = itemView.findViewById(R.id.iv_auto_image_slider);
            this.itemView = itemView;
        }
    }

}

