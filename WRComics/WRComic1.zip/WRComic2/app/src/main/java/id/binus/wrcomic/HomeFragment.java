package id.binus.wrcomic;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;
import java.util.ArrayList;

public class HomeFragment extends Fragment {
    BannerAdapter bannerAdapter;
    ComicViewAdapter comicViewAdapter;
    ArrayList<String> banners = new ArrayList<>();
    ArrayList<Comic> comicList = new ArrayList<>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        initDummyData();

        SliderView sliderView = rootView.findViewById(R.id.slider);
        RecyclerView recyclerView = rootView.findViewById(R.id.rv_comic);

        bannerAdapter = new BannerAdapter(getContext(), banners);
        sliderView.setSliderAdapter(bannerAdapter);
        sliderView.setIndicatorAnimation(IndicatorAnimationType.NONE);
        sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        sliderView.setAutoCycleDirection(SliderView.AUTO_CYCLE_DIRECTION_RIGHT);
        sliderView.setIndicatorSelectedColor(Color.WHITE);
        sliderView.setIndicatorUnselectedColor(Color.GRAY);
        sliderView.setScrollTimeInSec(3);
        sliderView.startAutoCycle();

        comicViewAdapter = new ComicViewAdapter(getContext(), comicList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(comicViewAdapter);

        return rootView;
    }

    private void initDummyData() {
        banners.add("https://ecs7.tokopedia.net/blog-tokopedia-com/uploads/2020/01/10-karakter-anime-rambut-putih-terpopuler.jpg");
        banners.add("https://ecs7.tokopedia.net/blog-tokopedia-com/uploads/2019/08/anime-action-terbaik.jpg");
        banners.add("https://jw-webmagazine.com/wp-content/uploads/2020/04/chihiro042-1.jpg");

        comicList.add(new Comic("https://upload.wikimedia.org/wikipedia/en/d/d6/Shingeki_no_Kyojin_manga_volume_1.jpg", "Attack On Titan", "Hajime Isayama", "Written and illustrated by Hajime Isayama. It is set in a world where humanity lives inside cities surrounded by three enormous walls that protect them from the gigantic man-eating humanoids referred to as Titans"));
        comicList.add(new Comic("https://upload.wikimedia.org/wikipedia/en/9/94/NarutoCoverTankobon1.jpg", "Naruto", "Masashi Kishimoto", "Naruto is a Japanese manga series written and illustrated by Masashi Kishimoto. It tells the story of Naruto Uzumaki, a young ninja who seeks recognition from his peers and dreams of becoming the Hokage, the leader of his village"));
        comicList.add(new Comic("https://upload.wikimedia.org/wikipedia/en/9/90/One_Piece%2C_Volume_61_Cover_%28Japanese%29.jpg", "One Piece", "Eiichiro Oda", "One Piece, is a Japanese manga series written and illustrated by Eiichiro Oda. It has been serialized in Shueisha's shōnen manga magazine Weekly Shōnen Jump since July 1997, with its individual chapters compiled into 99 tankōbon volumes as of February 2021"));
    }

}

//implementasi recyclerview
//https://stackoverflow.com/questions/40584424/simple-android-recyclerview-example

//implementasi banner
//https://github.com/smarteist/Android-Image-Slider