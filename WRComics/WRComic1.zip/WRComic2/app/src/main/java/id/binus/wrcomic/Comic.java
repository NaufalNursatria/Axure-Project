package id.binus.wrcomic;

/**
 * Created by IsmailR on 10/06/21.
 */
public class Comic {
    String cover;
    String title;
    String author;
    String desc;

    public Comic(String cover, String title, String author, String desc) {
        this.cover = cover;
        this.title = title;
        this.author = author;
        this.desc = desc;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
