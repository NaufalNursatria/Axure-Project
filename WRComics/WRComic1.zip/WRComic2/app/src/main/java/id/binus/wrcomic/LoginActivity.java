package id.binus.wrcomic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {

    TextInputEditText etUsername, etPassword;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        btnLogin = findViewById(R.id.btn_login);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnLogin.setBackgroundColor(getColor(R.color.purple_200));

                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();

                boolean inputNull = username.isEmpty() || password.isEmpty();
                boolean usernameConstraint = username.length() <= 4 || username.length() >= 8;

                if (inputNull) {
                    Toast.makeText(LoginActivity.this, "Username or Password cannot be empty",
                            Toast.LENGTH_SHORT).show();
                    btnLogin.setBackgroundColor(getColor(R.color.purple_500));
                } else if (usernameConstraint) {
                    Toast.makeText(LoginActivity.this, "Username must be greater than 4 and less than 8 characters",
                            Toast.LENGTH_SHORT).show();
                    btnLogin.setBackgroundColor(getColor(R.color.purple_500));
                } else if (!inputNull && !usernameConstraint) {
                    startActivity(new Intent(LoginActivity.this, MainActivity.class)
                    .putExtra("username", username));
                }
            }
        });
    }
}